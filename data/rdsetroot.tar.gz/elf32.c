/*	$OpenBSD: elf32.c,v 1.2 2015/01/20 04:41:01 krw Exp $	*/
#define ELFSIZE 32
#include "elfrd_size.c"
