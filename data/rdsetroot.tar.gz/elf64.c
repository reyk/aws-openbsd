/*	$OpenBSD: elf64.c,v 1.2 2015/01/20 04:41:01 krw Exp $	*/
#define ELFSIZE 64
#include "elfrd_size.c"
